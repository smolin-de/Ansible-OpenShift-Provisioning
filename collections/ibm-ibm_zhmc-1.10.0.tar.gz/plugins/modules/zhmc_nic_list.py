#!/usr/bin/python
# Copyright 2023 IBM Corp. All Rights Reserved.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#    http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

from __future__ import (absolute_import, division, print_function)
__metaclass__ = type

# For information on the format of the ANSIBLE_METADATA, DOCUMENTATION,
# EXAMPLES, and RETURN strings, see
# http://docs.ansible.com/ansible/dev_guide/developing_modules_documenting.html

ANSIBLE_METADATA = {
    'metadata_version': '1.1',
    'status': ['stableinterface'],
    'supported_by': 'community',
    'shipped_by': 'other',
    'other_repo_url': 'https://github.com/zhmcclient/zhmc-ansible-modules'
}

DOCUMENTATION = """
---
module: zhmc_nic_list
version_added: "2.9.0"
short_description: List NICs of a partition (DPM mode)
description:
  - List NICs on a specific partition of a CPC (Z system).
seealso:
  - module: ibm.ibm_zhmc.zhmc_nic
author:
  - Andreas Maier (@andy-maier)
requirements:
  - "The HMC userid must have object-access permissions to these objects:
    Target partition, CPC of target partition (only for HMC 2.13.0 and older)."
options:
  hmc_host:
    description:
      - The hostnames or IP addresses of a single HMC or of a list of redundant
        HMCs. A single HMC can be specified as a string type or as an HMC list
        with one item. An HMC list can be specified as a list type or as a
        string type containing a Python list representation.
      - The first available HMC of a list of redundant HMCs is used for the
        entire execution of the module.
    type: raw
    required: true
  hmc_auth:
    description:
      - The authentication credentials for the HMC.
    type: dict
    required: true
    suboptions:
      userid:
        description:
          - The userid (username) for authenticating with the HMC.
            This is mutually exclusive with providing O(hmc_auth.session_id).
        type: str
        required: false
        default: null
      password:
        description:
          - The password for authenticating with the HMC.
            This is mutually exclusive with providing O(hmc_auth.session_id).
        type: str
        required: false
        default: null
      session_id:
        description:
          - HMC session ID to be used.
            This is mutually exclusive with providing O(hmc_auth.userid) and
            O(hmc_auth.password) and can be created as described in the
            R(zhmc_session module,zhmc_session_module).
        type: str
        required: false
        default: null
      ca_certs:
        description:
          - Path name of certificate file or certificate directory to be used
            for verifying the HMC certificate. If null (default), the path name
            in the E(REQUESTS_CA_BUNDLE) environment variable or the path name
            in the E(CURL_CA_BUNDLE) environment variable is used, or if neither
            of these variables is set, the certificates in the Mozilla CA
            Certificate List provided by the 'certifi' Python package are used
            for verifying the HMC certificate.
        type: str
        required: false
        default: null
      verify:
        description:
          - If True (default), verify the HMC certificate as specified in the
            O(hmc_auth.ca_certs) parameter. If False, ignore what is specified in the
            O(hmc_auth.ca_certs) parameter and do not verify the HMC certificate.
        type: bool
        required: false
        default: true
  cpc_name:
    description:
      - "Name of the CPC with the partition whose NICs are to be listed."
    type: str
    required: true
  partition_name:
    description:
      - "Name of the partition whose NICs are to be listed."
    type: str
    required: true
  full_properties:
    description:
      - "If True, all properties of each NIC will be returned.
        Default: False."
      - "Note: A loop of 'Get NIC Properties' operations will be executed
         regardless of the value of O(full_properties) because the NIC name
         cannot be determined otherwise."
    type: bool
    required: false
    default: false
  expand_names:
    description:
      - "If True and O(full_properties) is set, additional artificial properties
         will be returned for the names and other identification of the backing
         adapter and port. Default: False."
    type: bool
    required: false
    default: false
  log_file:
    description:
      - "File path of a log file to which the logic flow of this module as well
         as interactions with the HMC are logged. If null, logging will be
         propagated to the Python root logger."
    type: str
    required: false
    default: null
  _faked_session:
    description:
      - "An internal parameter used for testing the module."
    type: raw
    required: false
    default: null
"""

EXAMPLES = """
---
# Note: The following examples assume that some variables named 'my_*' are set.

- name: List the NICs of a partition
  zhmc_nic_list:
    hmc_host: "{{ my_hmc_host }}"
    hmc_auth: "{{ my_hmc_auth }}"
    cpc_name: CPCA
    partition_name: PART1
  register: nic_list
"""

RETURN = """
changed:
  description: Indicates if any change has been made by the module.
    This will always be false.
  returned: always
  type: bool
msg:
  description: An error message that describes the failure.
  returned: failure
  type: str
nics:
  description: The list of NICs of the partition, with a subset of their
    properties.
  returned: success
  type: list
  elements: dict
  contains:
    name:
      description: "NIC name"
      type: str
    partition_name:
      description: "Name of the parent partition of the NIC"
      type: str
    cpc_name:
      description: "Name of the parent CPC of the partition"
      type: str
    "{additional_property}":
      description: Additional properties requested via O(full_properties).
        The property names will have underscores instead of hyphens.
      type: raw
    adapter_id:
      description: "Only present if O(expand_names=true) and
        O(full_properties=true): Adapter ID (PCHID) of the backing adapter of
        the NIC."
      type: str
    adapter_name:
      description: "Only present if O(expand_names=true) and
        O(full_properties=true): Name of the backing adapter of the NIC."
      type: str
    adapter_port:
      description: "Only present if O(expand_names=true) and
        O(full_properties=true): Port index of the backing port of the NIC."
      type: str
  sample:
    [
        {
            "cpc_name": "CPC1",
            "name": "nic1",
            "partition_name": "partition1"
        }
    ]
"""

import logging  # noqa: E402
import traceback  # noqa: E402
from ansible.module_utils.basic import AnsibleModule, \
    missing_required_lib  # noqa: E402

from ..module_utils.common import log_init, open_session, close_session, \
    hmc_auth_parameter, Error, common_fail_on_import_errors, parse_hmc_host, \
    blanked_params, ObjectsByUriCache  # noqa: E402

try:
    import zhmcclient
    IMP_ZHMCCLIENT_ERR = None
except ImportError:
    IMP_ZHMCCLIENT_ERR = traceback.format_exc()

# Python logger name for this module
LOGGER_NAME = 'zhmc_nic_list'

LOGGER = logging.getLogger(LOGGER_NAME)


def add_artificial_properties_expand(nic_properties, nic, adapters_cache):
    """
    Add artificial properties to the nic_properties dict. This function is
    called only when full_properties and expand_names are specified.

    Upon return, the nic_properties dict has been extended by these properties:

    * 'adapter_id': Adapter ID (PCHID) of the backing adapter of the NIC.
    * 'adapter_name': Name of the backing adapter of the NIC.
    * 'adapter_port': Port index of the backing port of the NIC.
    """

    partition = nic.manager.parent
    cpc = partition.manager.cpc
    session = cpc.manager.client.session

    # Add artificial properties for backing adapter:
    vswitch_uri = nic.prop('virtual-switch-uri', None)
    if vswitch_uri:
        # vswitch-based NIC (OSA, HS up to z16)
        vswitch = cpc.virtual_switches.find(**{'object-uri': vswitch_uri})
        adapter_uri = vswitch.get_property('backing-adapter-uri')
        adapter_port = vswitch.get_property('port')
    else:
        # adapter-based NIC (RoCE, CNA up to z16 or all adapter types
        # since z17)
        port_uri = nic.get_property('network-adapter-port-uri')
        port_props = session.get(port_uri)
        adapter_uri = port_props['parent']
        adapter_port = port_props['index']

    adapter = adapters_cache.resource_object(adapter_uri)
    nic_properties['adapter_id'] = adapter.get_property('adapter-id')
    nic_properties['adapter_name'] = adapter.name
    nic_properties['adapter_port'] = adapter_port


def perform_list(params):
    """
    List the NICs and return a subset of properties.

    Raises:
      ParameterError: An issue with the module parameters.
      zhmcclient.Error: Any zhmcclient exception can happen.
    """
    cpc_name = params.get('cpc_name')  # required
    partition_name = params.get('partition_name')  # required
    full_properties = params['full_properties']
    expand_names = params['expand_names']

    session, logoff = open_session(params)
    try:
        client = zhmcclient.Client(session)

        # TODO: Filtering with list_permitted_partitions() does not work.
        #       Using traditional approach for the time being.
        LOGGER.debug("Finding partition %s on CPC %s",
                     partition_name, cpc_name)
        cpc = client.cpcs.find(name=cpc_name)
        partition = cpc.partitions.find(name=partition_name)
        # The default exception handling is sufficient for the above.

        LOGGER.debug("Listing NICs of partition %s", partition.name)
        # We need to specify full_properties in order to get 'name'
        nics = partition.nics.list(full_properties=True)

        # Get the data for the name expansions only once
        if full_properties and expand_names:
            adapters_cache = ObjectsByUriCache(cpc.adapters)

        nic_list = []
        for nic in nics:

            nic_properties = {
                "cpc_name": cpc_name,
                "partition_name": partition_name,
                "name": nic.name,
            }

            if full_properties:
                for pname_hmc, pvalue in nic.properties.items():
                    pname = pname_hmc.replace('-', '_')
                    nic_properties[pname] = pvalue

            if full_properties and expand_names:
                add_artificial_properties_expand(
                    nic_properties, nic, adapters_cache)

            nic_list.append(nic_properties)

        return nic_list

    finally:
        close_session(session, logoff)


def main():
    """Main function"""

    # The following definition of module input parameters must match the
    # description of the options in the DOCUMENTATION string.
    argument_spec = dict(
        hmc_host=dict(required=True, type='raw'),
        hmc_auth=hmc_auth_parameter(),
        cpc_name=dict(required=True, type='str'),
        partition_name=dict(required=True, type='str'),
        full_properties=dict(required=False, type='bool', default=False),
        expand_names=dict(required=False, type='bool', default=False),
        log_file=dict(required=False, type='str', default=None),
        _faked_session=dict(required=False, type='raw'),
    )

    module = AnsibleModule(
        argument_spec=argument_spec,
        supports_check_mode=True)

    if IMP_ZHMCCLIENT_ERR is not None:
        module.fail_json(msg=missing_required_lib("zhmcclient"),
                         exception=IMP_ZHMCCLIENT_ERR)

    common_fail_on_import_errors(module)

    log_file = module.params['log_file']
    log_init(LOGGER_NAME, log_file)

    module.params['hmc_host'] = parse_hmc_host(module.params['hmc_host'])

    if LOGGER.isEnabledFor(logging.DEBUG):
        LOGGER.debug("Module entry: params: %r",
                     blanked_params(module.params))

    changed = False
    try:

        result_list = perform_list(module.params)

    except (Error, zhmcclient.Error) as exc:
        # These exceptions are considered errors in the environment or in user
        # input. They have a proper message that stands on its own, so we
        # simply pass that message on and will not need a traceback.
        msg = f"{exc.__class__.__name__}: {exc}"
        LOGGER.debug("Module exit (failure): msg: %r", msg)
        module.fail_json(msg=msg)
    # Other exceptions are considered module errors and are handled by Ansible
    # by showing the traceback.

    LOGGER.debug("Module exit (success): changed: %s, nics: %r",
                 changed, result_list)
    module.exit_json(changed=changed, nics=result_list)


if __name__ == '__main__':
    main()
